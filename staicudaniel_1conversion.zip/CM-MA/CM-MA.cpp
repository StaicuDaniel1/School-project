#include<fstream>
#include<iostream>
using namespace std;
int a[100][100];
int main()
{ int n,m;
    fstream f;
    f.open("input_f.dat",ios::in);
    f>>n;
    f>>m;
    int x,y;
    for(int i=0;i<m;i++)
    {
        f>>x>>y;
        a[x-1][y-1]=1;
        a[y-1][x-1]=1;
    }
    fstream g;
    g.open("output_f.dat",ios::out);
   for(int i=0;i<n;i++)
    {for(int j=0;j<n;j++)
        g<<a[i][j]<<" ";
        g<<endl;}

    f.close();
    g.close();
}
