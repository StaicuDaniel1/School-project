#include<fstream>
#include<iostream>
using namespace std;

int a[100][100],n;

int main()
{int x,y;

    fstream f;
    f.open("input_f.dat",ios::in);
    f>>n;

    fstream g;
    g.open("output_f.dat",ios::out);

    for(int i=0;i<n;i++)
    {
        f>>x;
        for(int j=0;j<n-1;j++)
        {f>>y;
        if(y) a[i][y-1]=1;}
    }
for(int i=0;i<n;i++)
    {for(int j=0;j<n;j++)
        g<<a[i][j]<<" ";
        g<<endl;}

    f.close();
    g.close();
}
